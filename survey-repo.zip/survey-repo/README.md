# Post-Training Feedback Survey

A lightweight, single-page CSAT survey built for Street Group's post-training feedback workflow. Hosted via GitHub Pages and submits responses directly to Google Sheets via a Google Apps Script web app.

---

## What it does

- Captures trainer attribution (Amy, Max, Mat, Jess)
- Collects CSAT score, usefulness, clarity, confidence, pace
- Accepts open-text feedback (what worked, improvements, anything missing)
- Optional NPS-lite score and final comments
- Lets respondents choose to submit anonymously or with their company name
- POSTs the full payload as JSON to a Google Apps Script endpoint
- Shows a confirmation screen on successful submission

---

## File structure

```
/
├── index.html        # The survey (single self-contained file)
├── README.md         # This file
└── .gitignore        # Ignores OS junk files
```

---

## Hosting on GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Under **Source**, select `main` branch and `/ (root)`
4. Click **Save**
5. Your survey will be live at `https://<your-username>.github.io/<repo-name>/`

---

## Updating the Apps Script endpoint

The Google Apps Script URL is defined at the top of the `<script>` block in `index.html`:

```js
const WEB_APP_URL = "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec";
```

Replace this value whenever you redeploy your Apps Script (a new deployment generates a new URL).

---

## Updating the trainer list

In `index.html`, find the `<select id="trainer-select">` block and edit the `<option>` values:

```html
<option value="Amy">Amy</option>
<option value="Max">Max</option>
<option value="Mat">Mat</option>
<option value="Jess">Jess</option>
```

---

## Google Apps Script — expected payload

The survey POSTs a JSON object with the following fields:

| Field | Type | Notes |
|---|---|---|
| `trainer` | string | Selected trainer name |
| `identityMode` | string | `"anon"` or `"named"` |
| `company` | string | Company name if named, else `""` |
| `csat` | number | 1–5 |
| `usefulness` | number or `""` | 1–5 scale |
| `clarity` | number or `""` | 1–5 scale |
| `confidence` | number or `""` | 1–5 scale |
| `pace` | string | `"slow"`, `"right"`, `"fast"`, or `""` |
| `helpful` | string | Open text |
| `improve` | string | Open text |
| `missingYN` | string | `"yes"`, `"no"`, or `""` |
| `missingText` | string | Open text if missingYN is yes |
| `nps` | number or `""` | 0–10 |
| `comments` | string | Open text |

Your Apps Script `doPost` function should parse it like this:

```js
function doPost(e) {
  const data = JSON.parse(e.postData.contents);
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  sheet.appendRow([
    new Date(),
    data.trainer,
    data.identityMode,
    data.company,
    data.csat,
    data.usefulness,
    data.clarity,
    data.confidence,
    data.pace,
    data.helpful,
    data.improve,
    data.missingYN,
    data.missingText,
    data.nps,
    data.comments
  ]);
  return ContentService.createTextOutput("OK");
}
```

Make sure the Apps Script is deployed as **Execute as: Me** and **Who has access: Anyone**.

---

## CSAT calculation (Google Sheets)

Once responses are flowing in, add these formulas to calculate your live CSAT %:

```
=COUNTIF(E:E, 4) + COUNTIF(E:E, 5)          ← satisfied + very satisfied
=COUNTA(E:E) - 1                              ← total responses (minus header)
=(satisfied / total) * 100                   ← CSAT %
```

Column E assumes `csat` is in column 5. Adjust if your sheet layout differs.
